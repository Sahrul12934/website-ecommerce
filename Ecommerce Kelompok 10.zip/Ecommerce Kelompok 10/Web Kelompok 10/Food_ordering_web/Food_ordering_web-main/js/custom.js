$(function () {

  // =============================
  // Toggle Keranjang
  // =============================
  $("#shopping-cart").on("click", function (e) {
    e.preventDefault();
    $("#cart-content").slideToggle();
  });

  // =============================
  // Hitung Total
  // =============================
  function hitungTotal() {
    let total = 0;

    // ORDER TABLE
    $(".tbl-full tr").each(function () {
      let harga = $(this).find("td:nth-child(6)").text();
      if (harga) {
        let angka = parseInt(harga.replace(/[^0-9]/g, ""));
        if (!isNaN(angka)) total += angka;
      }
    });

    $("#orderTotal").text("Rp " + total.toLocaleString("id-ID"));
    $("#cartTotal").text("Rp " + total.toLocaleString("id-ID"));

    // Badge cart
    let jumlahItem = $(".cart-table tr").length - 2;
    $(".badge").text(jumlahItem > 0 ? jumlahItem : 0);
  }

  // =============================
  // Hapus Item (Sinkron)
  // =============================
  $(document).on("click", ".btn-delete", function (e) {
    e.preventDefault();

    let index = $(this).closest("tr").index();

    // Hapus di order
    $(".tbl-full tr").eq(index).remove();

    // Hapus di cart
    $(".cart-table tr").eq(index).remove();

    hitungTotal();
  });

  // Jalankan saat load
  hitungTotal();
});
